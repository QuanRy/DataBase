﻿
namespace NEW_Lab_7_DB
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_IdCurrentRow = new System.Windows.Forms.TextBox();
            this.button_Reviews__Days = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button_ReviewsonTaxiCompanies = new System.Windows.Forms.Button();
            this.button_NewReviews_30_days = new System.Windows.Forms.Button();
            this.button_Top3taxiCompanies = new System.Windows.Forms.Button();
            this.button_FullReviews = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_TaxiCompanies = new System.Windows.Forms.ComboBox();
            this.comboBox_Clients = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_content = new System.Windows.Forms.TextBox();
            this.button_DeleteReviews = new System.Windows.Forms.Button();
            this.button_UpdateReviews = new System.Windows.Forms.Button();
            this.button_AddReviews = new System.Windows.Forms.Button();
            this.button_DeleteTaxiCompanies = new System.Windows.Forms.Button();
            this.button_UpdateTaxiCompanies = new System.Windows.Forms.Button();
            this.button_AddTaxiCompanies = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_taxi_rating = new System.Windows.Forms.TextBox();
            this.textBox_taxi_companies = new System.Windows.Forms.TextBox();
            this.button_DeleteClients = new System.Windows.Forms.Button();
            this.button_UpdateClients = new System.Windows.Forms.Button();
            this.button_AddClients = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_clients_nickname = new System.Windows.Forms.TextBox();
            this.textBox_telephone_number = new System.Windows.Forms.TextBox();
            this.button_AllReviews = new System.Windows.Forms.Button();
            this.button_AllClients = new System.Windows.Forms.Button();
            this.button_AllTaxiCompanies = new System.Windows.Forms.Button();
            this.dataGridViewWindow = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label_InfoEdit = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWindow)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(190)))), ((int)(((byte)(176)))));
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.textBox_IdCurrentRow);
            this.panel1.Controls.Add(this.button_Reviews__Days);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.button_ReviewsonTaxiCompanies);
            this.panel1.Controls.Add(this.button_NewReviews_30_days);
            this.panel1.Controls.Add(this.button_Top3taxiCompanies);
            this.panel1.Controls.Add(this.button_FullReviews);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.comboBox_TaxiCompanies);
            this.panel1.Controls.Add(this.comboBox_Clients);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox_content);
            this.panel1.Controls.Add(this.button_DeleteReviews);
            this.panel1.Controls.Add(this.button_UpdateReviews);
            this.panel1.Controls.Add(this.button_AddReviews);
            this.panel1.Controls.Add(this.button_DeleteTaxiCompanies);
            this.panel1.Controls.Add(this.button_UpdateTaxiCompanies);
            this.panel1.Controls.Add(this.button_AddTaxiCompanies);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.textBox_taxi_rating);
            this.panel1.Controls.Add(this.textBox_taxi_companies);
            this.panel1.Controls.Add(this.button_DeleteClients);
            this.panel1.Controls.Add(this.button_UpdateClients);
            this.panel1.Controls.Add(this.button_AddClients);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox_clients_nickname);
            this.panel1.Controls.Add(this.textBox_telephone_number);
            this.panel1.Controls.Add(this.button_AllReviews);
            this.panel1.Controls.Add(this.button_AllClients);
            this.panel1.Controls.Add(this.button_AllTaxiCompanies);
            this.panel1.Controls.Add(this.dataGridViewWindow);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.MinimumSize = new System.Drawing.Size(779, 486);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(839, 750);
            this.panel1.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(459, 571);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(188, 45);
            this.label13.TabIndex = 56;
            this.label13.Text = "Выберите с какой даты хотите видеть отзывы";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(16, 571);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(212, 45);
            this.label9.TabIndex = 55;
            this.label9.Text = "Выберите такси компанию в выпадающем списке";
            // 
            // textBox_IdCurrentRow
            // 
            this.textBox_IdCurrentRow.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_IdCurrentRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_IdCurrentRow.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox_IdCurrentRow.Location = new System.Drawing.Point(652, 654);
            this.textBox_IdCurrentRow.Multiline = true;
            this.textBox_IdCurrentRow.Name = "textBox_IdCurrentRow";
            this.textBox_IdCurrentRow.ReadOnly = true;
            this.textBox_IdCurrentRow.Size = new System.Drawing.Size(170, 24);
            this.textBox_IdCurrentRow.TabIndex = 24;
            // 
            // button_Reviews__Days
            // 
            this.button_Reviews__Days.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Reviews__Days.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Reviews__Days.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Reviews__Days.Location = new System.Drawing.Point(661, 571);
            this.button_Reviews__Days.Name = "button_Reviews__Days";
            this.button_Reviews__Days.Size = new System.Drawing.Size(160, 45);
            this.button_Reviews__Days.TabIndex = 54;
            this.button_Reviews__Days.Text = "Отзывы не более __ дней назад";
            this.button_Reviews__Days.UseVisualStyleBackColor = true;
            this.button_Reviews__Days.Click += new System.EventHandler(this.button_Reviews__Days_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(652, 631);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Id текущего элемента";
            // 
            // button_ReviewsonTaxiCompanies
            // 
            this.button_ReviewsonTaxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReviewsonTaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_ReviewsonTaxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ReviewsonTaxiCompanies.Location = new System.Drawing.Point(230, 571);
            this.button_ReviewsonTaxiCompanies.Name = "button_ReviewsonTaxiCompanies";
            this.button_ReviewsonTaxiCompanies.Size = new System.Drawing.Size(160, 45);
            this.button_ReviewsonTaxiCompanies.TabIndex = 53;
            this.button_ReviewsonTaxiCompanies.Text = " Показать отзывы по выбранной такси компании";
            this.button_ReviewsonTaxiCompanies.UseVisualStyleBackColor = true;
            this.button_ReviewsonTaxiCompanies.Click += new System.EventHandler(this.button_ReviewsonTaxiCompanies_Click);
            // 
            // button_NewReviews_30_days
            // 
            this.button_NewReviews_30_days.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_NewReviews_30_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_NewReviews_30_days.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_NewReviews_30_days.Location = new System.Drawing.Point(662, 511);
            this.button_NewReviews_30_days.Name = "button_NewReviews_30_days";
            this.button_NewReviews_30_days.Size = new System.Drawing.Size(160, 45);
            this.button_NewReviews_30_days.TabIndex = 52;
            this.button_NewReviews_30_days.Text = "Отзывы не более 30-ти дней назад";
            this.button_NewReviews_30_days.UseVisualStyleBackColor = true;
            this.button_NewReviews_30_days.Click += new System.EventHandler(this.button_NewReviews_30_days_Click);
            // 
            // button_Top3taxiCompanies
            // 
            this.button_Top3taxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Top3taxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_Top3taxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Top3taxiCompanies.Location = new System.Drawing.Point(490, 511);
            this.button_Top3taxiCompanies.Name = "button_Top3taxiCompanies";
            this.button_Top3taxiCompanies.Size = new System.Drawing.Size(160, 45);
            this.button_Top3taxiCompanies.TabIndex = 51;
            this.button_Top3taxiCompanies.Text = "Топ 3 такси компании по рейтингу";
            this.button_Top3taxiCompanies.UseVisualStyleBackColor = true;
            this.button_Top3taxiCompanies.Click += new System.EventHandler(this.button_Top3taxiCompanies_Click);
            // 
            // button_FullReviews
            // 
            this.button_FullReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_FullReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_FullReviews.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_FullReviews.Location = new System.Drawing.Point(668, 263);
            this.button_FullReviews.Name = "button_FullReviews";
            this.button_FullReviews.Size = new System.Drawing.Size(154, 31);
            this.button_FullReviews.TabIndex = 50;
            this.button_FullReviews.Text = "Подробные отзывы";
            this.button_FullReviews.UseVisualStyleBackColor = true;
            this.button_FullReviews.Click += new System.EventHandler(this.button_FullReviews_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(180, 446);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 20);
            this.label12.TabIndex = 49;
            this.label12.Text = "Такси компания";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(20, 446);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 20);
            this.label8.TabIndex = 48;
            this.label8.Text = "Клиент";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(16, 446);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 20);
            this.label11.TabIndex = 48;
            this.label11.Text = "Клиент";
            // 
            // comboBox_TaxiCompanies
            // 
            this.comboBox_TaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_TaxiCompanies.FormattingEnabled = true;
            this.comboBox_TaxiCompanies.Location = new System.Drawing.Point(184, 469);
            this.comboBox_TaxiCompanies.Name = "comboBox_TaxiCompanies";
            this.comboBox_TaxiCompanies.Size = new System.Drawing.Size(145, 24);
            this.comboBox_TaxiCompanies.TabIndex = 47;
            // 
            // comboBox_Clients
            // 
            this.comboBox_Clients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_Clients.FormattingEnabled = true;
            this.comboBox_Clients.Location = new System.Drawing.Point(20, 469);
            this.comboBox_Clients.Name = "comboBox_Clients";
            this.comboBox_Clients.Size = new System.Drawing.Size(155, 24);
            this.comboBox_Clients.TabIndex = 46;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker1.Location = new System.Drawing.Point(20, 534);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(228, 22);
            this.dateTimePicker1.TabIndex = 45;
            this.dateTimePicker1.Value = new System.DateTime(2022, 6, 12, 23, 52, 12, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(264, 509);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 20);
            this.label10.TabIndex = 44;
            this.label10.Text = "Отзыв";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(20, 509);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 20);
            this.label2.TabIndex = 43;
            this.label2.Text = "Дата и время ";
            // 
            // textBox_content
            // 
            this.textBox_content.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_content.Location = new System.Drawing.Point(268, 532);
            this.textBox_content.Multiline = true;
            this.textBox_content.Name = "textBox_content";
            this.textBox_content.Size = new System.Drawing.Size(193, 24);
            this.textBox_content.TabIndex = 42;
            // 
            // button_DeleteReviews
            // 
            this.button_DeleteReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DeleteReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_DeleteReviews.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_DeleteReviews.Location = new System.Drawing.Point(668, 465);
            this.button_DeleteReviews.Name = "button_DeleteReviews";
            this.button_DeleteReviews.Size = new System.Drawing.Size(154, 31);
            this.button_DeleteReviews.TabIndex = 40;
            this.button_DeleteReviews.Text = "Удалить отзыв";
            this.button_DeleteReviews.UseVisualStyleBackColor = true;
            this.button_DeleteReviews.Click += new System.EventHandler(this.button_DeleteReviews_Click);
            // 
            // button_UpdateReviews
            // 
            this.button_UpdateReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_UpdateReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_UpdateReviews.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_UpdateReviews.Location = new System.Drawing.Point(508, 465);
            this.button_UpdateReviews.Name = "button_UpdateReviews";
            this.button_UpdateReviews.Size = new System.Drawing.Size(154, 31);
            this.button_UpdateReviews.TabIndex = 39;
            this.button_UpdateReviews.Text = "Изменить отзыв";
            this.button_UpdateReviews.UseVisualStyleBackColor = true;
            this.button_UpdateReviews.Click += new System.EventHandler(this.button_UpdateReviews_Click);
            // 
            // button_AddReviews
            // 
            this.button_AddReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AddReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AddReviews.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddReviews.Location = new System.Drawing.Point(348, 465);
            this.button_AddReviews.Name = "button_AddReviews";
            this.button_AddReviews.Size = new System.Drawing.Size(154, 31);
            this.button_AddReviews.TabIndex = 38;
            this.button_AddReviews.Text = "Добавить отзыв";
            this.button_AddReviews.UseVisualStyleBackColor = true;
            this.button_AddReviews.Click += new System.EventHandler(this.button_AddReviews_Click);
            // 
            // button_DeleteTaxiCompanies
            // 
            this.button_DeleteTaxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DeleteTaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_DeleteTaxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_DeleteTaxiCompanies.Location = new System.Drawing.Point(668, 390);
            this.button_DeleteTaxiCompanies.Name = "button_DeleteTaxiCompanies";
            this.button_DeleteTaxiCompanies.Size = new System.Drawing.Size(154, 43);
            this.button_DeleteTaxiCompanies.TabIndex = 33;
            this.button_DeleteTaxiCompanies.Text = "Удалить такси компанию";
            this.button_DeleteTaxiCompanies.UseVisualStyleBackColor = true;
            this.button_DeleteTaxiCompanies.Click += new System.EventHandler(this.button_DeleteTaxiCompanies_Click);
            // 
            // button_UpdateTaxiCompanies
            // 
            this.button_UpdateTaxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_UpdateTaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_UpdateTaxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_UpdateTaxiCompanies.Location = new System.Drawing.Point(508, 390);
            this.button_UpdateTaxiCompanies.Name = "button_UpdateTaxiCompanies";
            this.button_UpdateTaxiCompanies.Size = new System.Drawing.Size(154, 43);
            this.button_UpdateTaxiCompanies.TabIndex = 32;
            this.button_UpdateTaxiCompanies.Text = "Изменить такси компанию";
            this.button_UpdateTaxiCompanies.UseVisualStyleBackColor = true;
            this.button_UpdateTaxiCompanies.Click += new System.EventHandler(this.button_UpdateTaxiCompanies_Click);
            // 
            // button_AddTaxiCompanies
            // 
            this.button_AddTaxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AddTaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AddTaxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddTaxiCompanies.Location = new System.Drawing.Point(348, 390);
            this.button_AddTaxiCompanies.Name = "button_AddTaxiCompanies";
            this.button_AddTaxiCompanies.Size = new System.Drawing.Size(154, 43);
            this.button_AddTaxiCompanies.TabIndex = 31;
            this.button_AddTaxiCompanies.Text = "Добавить такси компанию";
            this.button_AddTaxiCompanies.UseVisualStyleBackColor = true;
            this.button_AddTaxiCompanies.Click += new System.EventHandler(this.button_AddTaxiCompanies_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(163, 390);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 20);
            this.label6.TabIndex = 30;
            this.label6.Text = "Рейтинг от 1 до 5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(16, 390);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "Такси компания";
            // 
            // textBox_taxi_rating
            // 
            this.textBox_taxi_rating.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_taxi_rating.Location = new System.Drawing.Point(167, 413);
            this.textBox_taxi_rating.Multiline = true;
            this.textBox_taxi_rating.Name = "textBox_taxi_rating";
            this.textBox_taxi_rating.Size = new System.Drawing.Size(162, 24);
            this.textBox_taxi_rating.TabIndex = 28;
            this.textBox_taxi_rating.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_taxi_rating_KeyPress);
            // 
            // textBox_taxi_companies
            // 
            this.textBox_taxi_companies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_taxi_companies.Location = new System.Drawing.Point(16, 413);
            this.textBox_taxi_companies.Multiline = true;
            this.textBox_taxi_companies.Name = "textBox_taxi_companies";
            this.textBox_taxi_companies.Size = new System.Drawing.Size(142, 24);
            this.textBox_taxi_companies.TabIndex = 27;
            // 
            // button_DeleteClients
            // 
            this.button_DeleteClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DeleteClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_DeleteClients.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_DeleteClients.Location = new System.Drawing.Point(668, 332);
            this.button_DeleteClients.Name = "button_DeleteClients";
            this.button_DeleteClients.Size = new System.Drawing.Size(154, 31);
            this.button_DeleteClients.TabIndex = 26;
            this.button_DeleteClients.Text = "Удалить клиента";
            this.button_DeleteClients.UseVisualStyleBackColor = true;
            this.button_DeleteClients.Click += new System.EventHandler(this.button_DeleteClients_Click);
            // 
            // button_UpdateClients
            // 
            this.button_UpdateClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_UpdateClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_UpdateClients.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_UpdateClients.Location = new System.Drawing.Point(508, 332);
            this.button_UpdateClients.Name = "button_UpdateClients";
            this.button_UpdateClients.Size = new System.Drawing.Size(154, 31);
            this.button_UpdateClients.TabIndex = 23;
            this.button_UpdateClients.Text = "Изменить клиента";
            this.button_UpdateClients.UseVisualStyleBackColor = true;
            this.button_UpdateClients.Click += new System.EventHandler(this.button_UpdateClients_Click);
            // 
            // button_AddClients
            // 
            this.button_AddClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AddClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AddClients.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddClients.Location = new System.Drawing.Point(348, 332);
            this.button_AddClients.Name = "button_AddClients";
            this.button_AddClients.Size = new System.Drawing.Size(154, 31);
            this.button_AddClients.TabIndex = 22;
            this.button_AddClients.Text = "Добавить клиента";
            this.button_AddClients.UseVisualStyleBackColor = true;
            this.button_AddClients.Click += new System.EventHandler(this.button_AddClients_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(180, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "Nickname клиента";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(16, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Номер телефона";
            // 
            // textBox_clients_nickname
            // 
            this.textBox_clients_nickname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_clients_nickname.Location = new System.Drawing.Point(184, 336);
            this.textBox_clients_nickname.Multiline = true;
            this.textBox_clients_nickname.Name = "textBox_clients_nickname";
            this.textBox_clients_nickname.Size = new System.Drawing.Size(142, 24);
            this.textBox_clients_nickname.TabIndex = 19;
            // 
            // textBox_telephone_number
            // 
            this.textBox_telephone_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_telephone_number.Location = new System.Drawing.Point(16, 336);
            this.textBox_telephone_number.Multiline = true;
            this.textBox_telephone_number.Name = "textBox_telephone_number";
            this.textBox_telephone_number.Size = new System.Drawing.Size(159, 24);
            this.textBox_telephone_number.TabIndex = 18;
            this.textBox_telephone_number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_telephone_number_KeyPress);
            // 
            // button_AllReviews
            // 
            this.button_AllReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AllReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AllReviews.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AllReviews.Location = new System.Drawing.Point(463, 267);
            this.button_AllReviews.Name = "button_AllReviews";
            this.button_AllReviews.Size = new System.Drawing.Size(187, 28);
            this.button_AllReviews.TabIndex = 17;
            this.button_AllReviews.Text = "Вывести все отзывы";
            this.button_AllReviews.UseVisualStyleBackColor = true;
            this.button_AllReviews.Click += new System.EventHandler(this.button_AllReviews_Click_1);
            // 
            // button_AllClients
            // 
            this.button_AllClients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AllClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AllClients.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AllClients.Location = new System.Drawing.Point(253, 267);
            this.button_AllClients.Name = "button_AllClients";
            this.button_AllClients.Size = new System.Drawing.Size(187, 28);
            this.button_AllClients.TabIndex = 16;
            this.button_AllClients.Text = "Вывести всех клиентов";
            this.button_AllClients.UseVisualStyleBackColor = true;
            this.button_AllClients.Click += new System.EventHandler(this.button_AllClients_Click);
            // 
            // button_AllTaxiCompanies
            // 
            this.button_AllTaxiCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_AllTaxiCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_AllTaxiCompanies.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AllTaxiCompanies.Location = new System.Drawing.Point(24, 267);
            this.button_AllTaxiCompanies.Name = "button_AllTaxiCompanies";
            this.button_AllTaxiCompanies.Size = new System.Drawing.Size(209, 27);
            this.button_AllTaxiCompanies.TabIndex = 15;
            this.button_AllTaxiCompanies.Text = "Вывести все такси компании";
            this.button_AllTaxiCompanies.UseVisualStyleBackColor = true;
            this.button_AllTaxiCompanies.Click += new System.EventHandler(this.button_AllTaxiCompanies_Click);
            // 
            // dataGridViewWindow
            // 
            this.dataGridViewWindow.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewWindow.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewWindow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWindow.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewWindow.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewWindow.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridViewWindow.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewWindow.Name = "dataGridViewWindow";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewWindow.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewWindow.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(223)))), ((int)(((byte)(219)))));
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.dataGridViewWindow.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewWindow.Size = new System.Drawing.Size(839, 246);
            this.dataGridViewWindow.TabIndex = 14;
            this.dataGridViewWindow.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewWindow_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(224)))), ((int)(((byte)(217)))));
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label_InfoEdit);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 684);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(839, 66);
            this.panel2.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(8, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Окно вывода:";
            // 
            // label_InfoEdit
            // 
            this.label_InfoEdit.AutoSize = true;
            this.label_InfoEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_InfoEdit.Location = new System.Drawing.Point(131, 19);
            this.label_InfoEdit.Name = "label_InfoEdit";
            this.label_InfoEdit.Size = new System.Drawing.Size(21, 20);
            this.label_InfoEdit.TabIndex = 10;
            this.label_InfoEdit.Text = "...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 750);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(855, 788);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWindow)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_InfoEdit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridViewWindow;
        private System.Windows.Forms.Button button_AllClients;
        private System.Windows.Forms.Button button_AllTaxiCompanies;
        private System.Windows.Forms.Button button_AllReviews;
        private System.Windows.Forms.Button button_AddClients;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_clients_nickname;
        private System.Windows.Forms.TextBox textBox_telephone_number;
        private System.Windows.Forms.Button button_UpdateClients;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_IdCurrentRow;
        private System.Windows.Forms.Button button_DeleteClients;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_taxi_rating;
        private System.Windows.Forms.TextBox textBox_taxi_companies;
        private System.Windows.Forms.Button button_DeleteTaxiCompanies;
        private System.Windows.Forms.Button button_UpdateTaxiCompanies;
        private System.Windows.Forms.Button button_AddTaxiCompanies;
        private System.Windows.Forms.Button button_DeleteReviews;
        private System.Windows.Forms.Button button_UpdateReviews;
        private System.Windows.Forms.Button button_AddReviews;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_content;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_TaxiCompanies;
        private System.Windows.Forms.ComboBox comboBox_Clients;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_FullReviews;
        private System.Windows.Forms.Button button_Top3taxiCompanies;
        private System.Windows.Forms.Button button_NewReviews_30_days;
        private System.Windows.Forms.Button button_ReviewsonTaxiCompanies;
        private System.Windows.Forms.Button button_Reviews__Days;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
    }
}

