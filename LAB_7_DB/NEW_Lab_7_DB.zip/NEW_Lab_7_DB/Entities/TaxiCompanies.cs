﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEW_Lab_7_DB.Entities
{
    public class TaxiCompanies
    {
        public int id_taxi_companies { get; set; }

        public string name { get; set; }

        public float rating { get; set; }

        public TaxiCompanies(int id_taxi_companies, string name, float rating)
        {
            this.id_taxi_companies = id_taxi_companies;
            this.name = name;
            this.rating = rating;
        }
        public TaxiCompanies(string name)
        {
            this.name = name;
        }
    }
}
