﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEW_Lab_7_DB.Entities
{
    public class FullReviews
    {
        public int id_reviews { get; set; }

        public string date_time { get; set; }

        public string content { get; set; }

        public string nickname_clients { get; set; }

        public string name_taxi_companies { get; set; }

        public string clients_telephone_number { get; set; }

        public float taxi_companies_rating { get; set; }

        public FullReviews(int id_reviews, string date_time, string content, string nickname_clients, string name_taxi_companies, string clients_telephone_number, float taxi_companies_rating)
        {
            this.id_reviews = id_reviews;
            this.date_time = date_time;
            this.content = content;
            this.nickname_clients = nickname_clients;
            this.name_taxi_companies = name_taxi_companies;
            this.clients_telephone_number = clients_telephone_number;
            this.taxi_companies_rating = taxi_companies_rating;
        }
    }
}
