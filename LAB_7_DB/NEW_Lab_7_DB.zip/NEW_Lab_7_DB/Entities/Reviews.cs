﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEW_Lab_7_DB.Entities
{
    public class Reviews
    {
        public int id_reviews { get; set; }

        public string date_time { get; set; }

        public string content { get; set; }

        public string nickname_clients { get; set; }

        public string name_taxi_companies { get; set; }

        public int id_clients_fk { get; set; }

        public int id_taxi_companies_fk { get; set; }

        public Reviews(int id_reviews, string date_time, string content, string nickname_clients, string name_taxi_companies, int id_clients_fk, int id_taxi_companies_fk)
        {
            this.id_reviews = id_reviews;
            this.date_time = date_time;
            this.content = content;
            this.nickname_clients = nickname_clients;
            this.name_taxi_companies = name_taxi_companies;
            this.id_clients_fk = id_clients_fk;
            this.id_taxi_companies_fk = id_taxi_companies_fk;
        }
    }
}
