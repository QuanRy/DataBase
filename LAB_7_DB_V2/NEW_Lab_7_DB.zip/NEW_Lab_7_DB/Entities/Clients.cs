﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEW_Lab_7_DB.Entities
{
    public class Clients
    {
        public int id_clients { get; set; }

        public string telephone_number { get; set; }

        public string nickname { get; set; }

        public Clients(int id_clients, string telephone_number, string nickname)
        {
            this.id_clients = id_clients;
            this.telephone_number = telephone_number;
            this.nickname = nickname;
        }

        public Clients(string nickname)
        {
            this.nickname = nickname;
        }

        public Clients(int id_clients)
        {
            this.id_clients = id_clients;
        }
    }
}
